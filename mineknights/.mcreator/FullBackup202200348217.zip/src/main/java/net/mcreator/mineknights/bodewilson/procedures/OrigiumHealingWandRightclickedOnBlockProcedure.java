package net.mcreator.mineknights.bodewilson.procedures;

public class OrigiumHealingWandRightclickedOnBlockProcedure {
	public static void execute() {
	}
}

package net.mcreator.mineknights.bodewilson.procedures;

public class OrigiumHealingWandRightclickedEntityProcedure {
	public static void execute() {
	}
}
